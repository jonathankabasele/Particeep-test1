function ajouterTitre(holder) {
	newTitre = document.createElement('span');
    newTitre.innerHTML = "<span class=\"titre-video\">TITRE</span></br>";
    	
    holder.appendChild(newTitre);
    
    contenuTitre = document.createElement('p');
    let idContenuTitre = "titre-" + i.toString(); 
    contenuTitre.setAttribute("id", idContenuTitre);
    contenuTitre.innerHTML = "<p>" + movies[i].title + "</p>";
    
    holder.appendChild(contenuTitre); 	
   
}

function ajouterCategory(holder) {
	newCategory = document.createElement('span');
    newCategory.innerHTML = "<span class=\"zone-categorie\">CATEGORY</span>";
    	
    holder.appendChild(newCategory);
    
    contenuCategory = document.createElement('p');
    let idContenuCategory = "category-" + i.toString(); 
    contenuCategory.setAttribute("id", idContenuCategory);
    contenuCategory.innerHTML = "<p>" + movies[i].category + "</p>";
    	
    holder.appendChild(contenuCategory);
}

function ajouterLikes(holder){
	newLikes = document.createElement('span');
    newLikes.innerHTML = "<span class=\"zone-likes\">LIKES</span>";
    	
    holder.appendChild(newLikes);
    
    contenuLikes = document.createElement('p');
    let idContenuLikes = "likes-" + i.toString(); 
    contenuLikes.setAttribute("id", idContenuLikes);
    contenuLikes.innerHTML = "<p>" + movies[i].likes + "</p> ";
    	
    holder.appendChild(contenuLikes);
}

function ajouterDisLikes(holder){
	newDisLikes = document.createElement('span');
    newDisLikes.innerHTML = "<span class=\"zone-dislikes\">DISLIKES</span>";
    	
    holder.appendChild(newDisLikes);
    
    contenuDisLikes = document.createElement('p');
    let idContenuDisLikes = "likes-" + i.toString(); 
    contenuDisLikes.setAttribute("id", idContenuDisLikes);
    contenuDisLikes.innerHTML = "<p>" + movies[i].dislikes + "</p></br></br></br>";
    	
    holder.appendChild(contenuDisLikes);
}
